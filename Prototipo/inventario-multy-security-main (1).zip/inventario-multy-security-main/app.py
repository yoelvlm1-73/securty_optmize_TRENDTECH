"""API + interfaz web. Ejecutar:  python app.py  ->  http://localhost:5000"""
import re
from datetime import datetime
from bson import ObjectId
from flask import Flask, jsonify, request, send_from_directory
from pymongo import MongoClient
import config
from codigos import asegurar_codigos, siguiente_codigo

app = Flask(__name__, static_folder="static")
db = MongoClient(config.MONGO_URI)[config.DB_NAME]
try:
    asegurar_codigos(db)
except Exception as e:
    print("AVISO: no se pudieron asignar códigos a los proyectos:", e)


def proyecto_por(valor):
    """Busca un proyecto por código o por nombre; si no existe lo crea con código automático."""
    v = (valor or "").strip()
    if not v:
        return None
    p = db.proyectos.find_one({"codigo": v.upper()}) or db.proyectos.find_one({"nombre": v})
    if not p:
        p = {"nombre": v, "codigo": siguiente_codigo(db)}
        db.proyectos.insert_one(p)
    return p


def ser(d):
    if isinstance(d, list):
        return [ser(x) for x in d]
    if isinstance(d, dict):
        return {k: ser(v) for k, v in d.items()}
    if isinstance(d, ObjectId):
        return str(d)
    if isinstance(d, datetime):
        return d.date().isoformat()
    return d


def fecha(s):
    return datetime.fromisoformat(s) if s else None


def error(msg, code=400):
    return jsonify({"error": msg}), code


@app.get("/")
def home():
    return send_from_directory("static", "index.html")


@app.get("/api/resumen")
def resumen():
    return jsonify({
        "productos": db.productos.count_documents({}),
        "sin_stock": db.productos.count_documents({"stock_actual": {"$lte": 0}}),
        "movimientos": db.movimientos.count_documents({}),
        "proyectos": db.proyectos.count_documents({}),
    })


# ---------- Productos ----------
@app.get("/api/productos")
def productos():
    q = request.args.get("q", "").strip()
    filtro = {"$or": [{"codigo": {"$regex": q, "$options": "i"}},
                      {"descripcion": {"$regex": q, "$options": "i"}}]} if q else {}
    return jsonify(ser(list(db.productos.find(filtro).sort("codigo", 1))))


@app.post("/api/productos")
def producto_nuevo():
    d = request.json or {}
    if not d.get("descripcion"):
        return error("Falta la descripción.")
    cod = (d.get("codigo") or "").strip() or None
    if cod and db.productos.find_one({"codigo": cod}):
        return error(f"Ya existe el código {cod}.")
    db.productos.insert_one({
        "codigo": cod, "descripcion": d["descripcion"].strip(),
        "unidad_medida": d.get("unidad_medida") or None, "diametro": d.get("diametro"),
        "stock_actual": float(d.get("stock_actual") or 0),
        "valor_unitario": d.get("valor_unitario"), "creado": datetime.now()})
    return jsonify({"ok": True}), 201


# ---------- Movimientos (actualizan el stock) ----------
@app.get("/api/movimientos")
def movimientos():
    filtro = {}
    cod = request.args.get("proyecto", "").strip()
    if cod:
        p = db.proyectos.find_one({"codigo": cod.upper()})
        filtro = {"proyecto": p["nombre"] if p else cod}
    return jsonify(ser(list(db.movimientos.find(filtro).sort("fecha", -1).limit(500))))


@app.post("/api/movimientos")
def movimiento_nuevo():
    d = request.json or {}
    tipo, cod = d.get("tipo"), (d.get("codigo") or "").strip()
    try:
        cant = float(d.get("cantidad"))
    except (TypeError, ValueError):
        return error("La cantidad debe ser un número.")
    if tipo not in ("ingreso", "salida") or cant <= 0:
        return error("Indica tipo (ingreso/salida) y una cantidad mayor a 0.")
    prod = db.productos.find_one({"codigo": cod})
    if not prod:
        return error(f"No existe el producto con código {cod}.", 404)
    antes = prod.get("stock_actual") or 0
    if tipo == "salida" and cant > antes:
        return error(f"Stock insuficiente: hay {antes:g} y se piden {cant:g}.")
    db.productos.update_one({"_id": prod["_id"]},
                            {"$inc": {"stock_actual": cant if tipo == "ingreso" else -cant}})
    proy = proyecto_por(d.get("proyecto"))
    if d.get("recibido_por"):
        n = d["recibido_por"].strip()
        db.personas.update_one({"nombre": n}, {"$setOnInsert": {"nombre": n, "activo": True}}, upsert=True)
    db.movimientos.insert_one({
        "fecha": fecha(d.get("fecha")) or datetime.now().replace(hour=0, minute=0, second=0, microsecond=0),
        "codigo": cod, "descripcion": prod["descripcion"], "tipo": tipo, "cantidad": cant,
        "cantidad_existente": antes, "recibido_por": d.get("recibido_por") or None,
        "proyecto": proy["nombre"] if proy else None,
        "proyecto_codigo": proy["codigo"] if proy else None, "area_uso": d.get("area_uso") or None,
        "observacion": d.get("observacion") or None})
    return jsonify({"ok": True, "stock_nuevo": antes + (cant if tipo == "ingreso" else -cant)}), 201


# ---------- Proyectos / personas ----------
@app.get("/api/proyectos")
def proyectos():
    return jsonify(ser(list(db.proyectos.find().sort("codigo", 1))))


@app.post("/api/proyectos")
def proyecto_nuevo():
    d = request.json or {}
    n = (d.get("nombre") or "").strip()
    cod = (d.get("codigo") or "").strip().upper() or None
    if not n:
        return error("Falta el nombre del proyecto.")
    if db.proyectos.find_one({"nombre": n}):
        return error(f"Ya existe un proyecto llamado {n}.")
    if cod and db.proyectos.find_one({"codigo": cod}):
        return error(f"El código {cod} ya está en uso.")
    cod = cod or siguiente_codigo(db)
    db.proyectos.insert_one({"nombre": n, "codigo": cod})
    return jsonify({"ok": True, "codigo": cod}), 201


@app.get("/api/personas")
def personas():
    return jsonify(ser(list(db.personas.find().sort("nombre", 1))))


@app.post("/api/personas")
def persona_nueva():
    d = request.json or {}
    n = (d.get("nombre") or "").strip()
    if not n:
        return error("Falta el nombre.")
    if db.personas.find_one({"nombre": {"$regex": f"^{re.escape(n)}$", "$options": "i"}}):
        return error(f"{n} ya está registrado.")
    db.personas.insert_one({"nombre": n, "cargo": (d.get("cargo") or "").strip() or None,
                            "activo": True, "creado": datetime.now()})
    return jsonify({"ok": True}), 201


# ---------- Mobiliario / materiales en préstamo ----------
@app.get("/api/mobiliario")
def mobiliario():
    return jsonify(ser(list(db.mobiliario.find().sort("fecha_entrada", -1))))


@app.post("/api/mobiliario")
def mobiliario_nuevo():
    d = request.json or {}
    if not d.get("producto"):
        return error("Falta el producto.")
    db.mobiliario.insert_one({
        "codigo": d.get("codigo") or None, "producto": d["producto"].strip(),
        "fecha_entrada": fecha(d.get("fecha_entrada")) or datetime.now(),
        "cantidad_entra": float(d.get("cantidad_entra") or 0),
        "cantidad_sale": float(d.get("cantidad_sale") or 0),
        "regresa": bool(d.get("regresa")), "recibe": d.get("recibe") or None,
        "destino": d.get("destino") or None, "fecha_salida": fecha(d.get("fecha_salida")),
        "observacion": d.get("observacion") or None})
    return jsonify({"ok": True}), 201


if __name__ == "__main__":
    app.run(debug=True, port=5000)
