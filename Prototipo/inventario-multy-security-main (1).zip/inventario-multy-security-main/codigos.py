"""Códigos automáticos para proyectos (PRY-001, PRY-002, ...)."""
import re


def siguiente_codigo(db, prefijo="PRY"):
    mayor = 0
    for p in db.proyectos.find({"codigo": {"$type": "string"}}, {"codigo": 1}):
        m = re.search(r"(\d+)$", p["codigo"])
        if m:
            mayor = max(mayor, int(m.group(1)))
    return f"{prefijo}-{mayor + 1:03d}"


def asegurar_codigos(db):
    """Da código a los proyectos que no tengan y crea el índice único."""
    sin = db.proyectos.find({"$or": [{"codigo": {"$exists": False}}, {"codigo": None}]}).sort("nombre", 1)
    for p in list(sin):
        db.proyectos.update_one({"_id": p["_id"]}, {"$set": {"codigo": siguiente_codigo(db)}})
    db.proyectos.create_index("codigo", unique=True, partialFilterExpression={"codigo": {"$type": "string"}})
