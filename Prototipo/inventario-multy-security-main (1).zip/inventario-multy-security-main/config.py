"""Configuración. Cambia MONGO_URI por tu cadena de Atlas si no usas MongoDB local."""
import os

MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.environ.get("DB_NAME", "ymg_inventario")
EXCEL_PATH = os.environ.get("EXCEL_PATH", "Inventario_2026_secur.xlsx")

# Nombres de proyecto escritos distinto en el Excel -> un solo nombre.
# Edita esta tabla con los nombres completos reales de tus proyectos.
PROYECTO_ALIASES = {
    "saint m": "Saint M",
    "saint mich": "Saint M",
    "mont": "Mont",
    "jardines": "Jardines",
    "jardines casa": "Jardines",
}
