# Inventario Multy Security (MongoDB)

## Puesta en marcha
```bash
pip install -r requirements.txt
# Si usas Atlas: export MONGO_URI="mongodb+srv://usuario:clave@cluster.mongodb.net"
python importar_excel.py --dry-run   # revisa qué va a importar
python importar_excel.py             # crea colecciones, índices y carga el Excel
python app.py                        # abre http://localhost:5000
```
Por defecto usa `mongodb://localhost:27017` y la base `ymg_inventario` (ver `config.py`).

## Diseño de la base (colecciones = "tablas")
| Colección | Campos | Origen en el Excel |
|---|---|---|
| **productos** | codigo (único), descripcion, unidad_medida, diametro, stock_actual, valor_unitario, creado | hoja `2026` (+ unidad y diámetro de `2026 (2)`) |
| **movimientos** | fecha, codigo → productos, descripcion, tipo (ingreso/salida), cantidad, cantidad_existente (stock antes), recibido_por → personas, proyecto → proyectos, area_uso, observacion | hoja `entradas y salidas` |
| **mobiliario** | codigo, producto, fecha_entrada, cantidad_entra, cantidad_sale, regresa (bool), recibe → personas, destino, fecha_salida, observacion | hoja `inventaro moviliario` |
| **proyectos** | codigo (único, automático PRY-001...), nombre (único) | columna proyecto |
| **personas** (usuarios) | nombre (único), cargo, activo | columnas recibido por / recibe; se agregan desde la pestaña Usuarios |

Relaciones: un producto tiene muchos movimientos (por `codigo`); un movimiento pertenece a un proyecto y lo recibe una persona (por nombre).

## Reglas de la interfaz
- Registrar un movimiento actualiza `productos.stock_actual` (ingreso suma, salida resta) y guarda el stock previo.
- No permite una salida mayor al stock disponible.
- El importador es repetible: no duplica productos ni movimientos.
- Los movimientos del Excel se importan como historial y no modifican el stock de la hoja 2026.

## Pendiente por definir
- 9 productos del Excel no tienen código (el importador los lista).
- Nombres completos de proyectos: edita `PROYECTO_ALIASES` en `config.py`.
- Inicio de sesión y permisos: la pestaña Usuarios solo registra personas, no crea contraseñas.
