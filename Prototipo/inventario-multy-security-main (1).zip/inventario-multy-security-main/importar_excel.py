"""Lee Inventario_2026_secur.xlsx y crea/llena la base de datos en MongoDB.

Uso:
  python importar_excel.py --dry-run          # solo muestra lo que importaría
  python importar_excel.py                    # importa (se puede repetir sin duplicar)
  python importar_excel.py --reset            # borra las colecciones y vuelve a importar
"""
import argparse, hashlib, re
from datetime import datetime

import openpyxl
import config


def limpio(v):
    if isinstance(v, str):
        v = re.sub(r"\s+", " ", v).strip()
        return v or None
    return v


def num(v):
    return v if isinstance(v, (int, float)) else None


def proyecto(v):
    v = limpio(v)
    if not v:
        return None
    return config.PROYECTO_ALIASES.get(v.lower(), v.title())


def hid(*partes):
    return hashlib.md5("|".join(str(p) for p in partes).encode()).hexdigest()[:24]


def leer(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    ahora = datetime.now()

    # Detalle extra por código (unidad de medida, diámetro) desde "2026 (2)"
    extra = {}
    for r in wb["2026 (2)"].iter_rows(min_row=2, values_only=True):
        c = limpio(r[0])
        if c:
            extra[c] = {"unidad_medida": limpio(r[3]), "diametro": num(r[2])}

    productos = []
    for r in wb["2026"].iter_rows(min_row=2, values_only=True):
        cod, desc = limpio(r[0]), limpio(r[1])
        if not desc:
            continue
        e = extra.get(cod, {})
        productos.append({
            "codigo": cod, "descripcion": desc,
            "unidad_medida": e.get("unidad_medida"), "diametro": e.get("diametro"),
            "stock_actual": num(r[2]) or 0, "valor_unitario": num(r[3]),
            "creado": ahora,
        })

    movimientos = []
    for r in wb["entradas y salidas"].iter_rows(min_row=2, values_only=True):
        if not isinstance(r[0], datetime):
            continue
        tipo = (limpio(r[5]) or "").lower()
        tipo = "ingreso" if tipo.startswith("ing") else "salida"
        m = {
            "fecha": r[0], "descripcion": limpio(r[1]), "codigo": limpio(r[2]),
            "cantidad_existente": num(r[3]), "cantidad": num(r[4]) or 0, "tipo": tipo,
            "recibido_por": limpio(r[6]), "proyecto": proyecto(r[7]),
            "area_uso": limpio(r[8]), "observacion": limpio(r[9]),
        }
        m["_id"] = hid(m["fecha"], m["codigo"], tipo, m["cantidad"], m["recibido_por"])
        movimientos.append(m)

    mobiliario = []
    for r in wb["inventaro moviliario"].iter_rows(min_row=2, values_only=True):
        if not (limpio(r[0]) or limpio(r[2])):
            continue
        reg = (limpio(r[5]) or "").lower()
        m = {
            "codigo": limpio(r[0]), "producto": limpio(r[2]),
            "fecha_entrada": r[1] if isinstance(r[1], datetime) else None,
            "cantidad_entra": num(r[3]) or 0, "cantidad_sale": num(r[4]) or 0,
            "regresa": reg in ("si", "sí"), "recibe": limpio(r[6]),
            "destino": limpio(r[7]),
            "fecha_salida": r[8] if isinstance(r[8], datetime) else None,
            "observacion": limpio(r[9]),
        }
        m["_id"] = hid(m["codigo"], m["producto"], m["fecha_entrada"])
        mobiliario.append(m)

    nombres_p = {m["proyecto"] for m in movimientos if m["proyecto"]}
    nombres_p |= {proyecto(r[8]) for r in wb["2026 (2)"].iter_rows(min_row=2, values_only=True) if proyecto(r[8])}
    proyectos = [{"nombre": n} for n in sorted(nombres_p)]
    personas = sorted({m["recibido_por"] for m in movimientos if m["recibido_por"]}
                      | {m["recibe"] for m in mobiliario if m["recibe"]})
    personas = [{"nombre": n} for n in personas]
    return productos, movimientos, mobiliario, proyectos, personas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--excel", default=config.EXCEL_PATH)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--reset", action="store_true")
    a = ap.parse_args()

    productos, movs, mob, proys, pers = leer(a.excel)
    sin_codigo = [p["descripcion"] for p in productos if not p["codigo"]]
    print(f"productos: {len(productos)} | movimientos: {len(movs)} | mobiliario: {len(mob)} "
          f"| proyectos: {len(proys)} | personas: {len(pers)}")
    if sin_codigo:
        print(f"AVISO: {len(sin_codigo)} productos sin código en el Excel (se importan igual):")
        for d in sin_codigo:
            print("   -", d)
    if a.dry_run:
        return

    from pymongo import MongoClient, ASCENDING
    db = MongoClient(config.MONGO_URI)[config.DB_NAME]
    if a.reset:
        for c in ("productos", "movimientos", "mobiliario", "proyectos", "personas"):
            db[c].drop()

    db.productos.create_index("codigo", unique=True,
                              partialFilterExpression={"codigo": {"$type": "string"}})
    db.productos.create_index("descripcion")
    db.movimientos.create_index([("fecha", -1)])
    db.movimientos.create_index("codigo")
    db.proyectos.create_index("nombre", unique=True)
    db.personas.create_index("nombre", unique=True)

    for p in productos:
        filtro = {"codigo": p["codigo"]} if p["codigo"] else {"codigo": None, "descripcion": p["descripcion"]}
        creado = p.pop("creado")
        db.productos.update_one(filtro, {"$set": p, "$setOnInsert": {"creado": creado}}, upsert=True)
    for col, docs in (("movimientos", movs), ("mobiliario", mob)):
        for d in docs:
            db[col].replace_one({"_id": d["_id"]}, d, upsert=True)
    for col, docs in (("proyectos", proys), ("personas", pers)):
        for d in docs:
            db[col].update_one(d, {"$set": d}, upsert=True)
    from codigos import asegurar_codigos
    asegurar_codigos(db)
    print("Listo. Base:", config.DB_NAME)


if __name__ == "__main__":
    main()
